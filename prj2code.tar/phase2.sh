#!/bin/bash 

# remove existing index files
rm *.idx

# creates index files using supplied script break.pl
cat reviews.txt | perl break.pl | db_load -c duplicates=1 -T -t hash rw.idx
sort --unique pterms.txt | perl break.pl | db_load -c duplicates=1 -T -t btree pt.idx
sort --unique rterms.txt | perl break.pl | db_load -c duplicates=1 -T -t btree rt.idx
sort --unique scores.txt | perl break.pl | db_load -c duplicates=1 -T -t btree sc.idx


#cat reviews.txt | perl break.pl | tee reviewsSorted.txt
#sort --unique pterms.txt | perl break.pl | tee ptermsSorted.txt
#sort --unique rterms.txt | perl break.pl | tee rtermsSorted.txt
#sort --unique scores.txt | perl break.pl | tee scoresSorted.txt

#db_load -f reviewsSorted.txt -T -t hash rw.idx
#db_load -f ptermsSorted.txt -T -t btree pt.idx
#db_load -f rtermsSorted.txt -T -t btree rt.idx
#db_load -f scoresSorted.txt -T -t btree sc.idx

#sort --unique --output=ptermsSorted.txt pterms.txt
#sort --unique --output=rtermsSorted.txt rterms.txt
#sort --unique --output=scoresSorted.txt scores.txt
